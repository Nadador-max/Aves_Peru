# =============================================
# SCRIPT DE PROCESAMIENTO DE AVES
# Consultas a IUCN, CITES y CMS
# =============================================

# 1. CARGA DE PAQUETES NECESARIOS
if (!require(dplyr)) install.packages("dplyr")
if (!require(tidyr)) install.packages("tidyr")
if (!require(purrr)) install.packages("purrr")
if (!require(avesperu)) install.packages("avesperu")
if (!requireNamespace("devtools", quietly = TRUE)) install.packages("devtools")
if (!requireNamespace("iucnredlist", quietly = TRUE)) devtools::install_github("IUCN-UK/iucnredlist")
if (!require(rcites)) install.packages("rcites")

library(dplyr)
library(tidyr)
library(purrr)
library(avesperu)
library(iucnredlist)
library(rcites)

# 2. DEFINIR RUTA DE TRABAJO Y ARCHIVO CSV
# CAMBIA ESTA RUTA SEGÚN TU COMPUTADORA
setwd("C:/Users/GERARDO/Desktop/script_aves") 
dir()

# CAMBIAR aves_ejemplo por tu archivo de entrada
datos_aves <- read.csv("datos/ja.csv", sep = ";", header = TRUE)

# 3. CLAVES DE API
api_key_iucn <- "Pu7GTJk2wx69LqfZ1sPSUz11xEWZmDPL5Cer"
api_key_speciesplus <- "rpOp4RQqsGiJeelXHmArpgtt"

# 4. CONECTARSE A LAS APIs
api <- init_api(api_key_iucn)
set_token(api_key_speciesplus)

# 5. CARGAR FUNCIONES EXTERNAS
source("Private/IUCNfunctions.R")
source("Private/CITES_CMS_functions.R")
source("Private/Plenge_match.R")

# 6. PROCESAR TODO
datos_aves <- procesar_todo(datos_aves, api)

# 7. AÑADIR CATEGORÍA DEL MINAGRI DESDE GITHUB
url_minagri <- "https://raw.githubusercontent.com/Nadador-max/Aves_Peru/main/categorias_miangri2014.txt"
decreto_minagri <- read.delim(url_minagri, sep = "\t", header = TRUE, stringsAsFactors = FALSE)

# Eliminar columna spanish_name para evitar duplicado al hacer join
decreto_minagri <- decreto_minagri %>% select(-spanish_name)

# Hacer el join por scientific_name
datos_aves <- left_join(datos_aves, decreto_minagri, by = "scientific_name")


# 8. GUARDAR RESULTADO FINAL
write.csv(datos_aves, "Resultados/aves_completo.csv", row.names = FALSE)



