obtener_cites_cms_rcites <- function(nombre_especie) {
  if (is.na(nombre_especie) || nombre_especie == "") {
    return(tibble(cites_listing = NA, cms_presence = NA))
  }

  res_cites <- tryCatch(
    spp_taxonconcept(query = nombre_especie, taxonomy = "CITES"),
    error = function(e) NULL
  )

  cites <- if (!is.null(res_cites) && !is.null(res_cites$general$cites_listing)) {
    val <- res_cites$general$cites_listing
    if (!is.na(val) && val == "NC") NA else val
  } else {
    NA
  }

  res_cms <- tryCatch(
    spp_taxonconcept(query = nombre_especie, taxonomy = "CMS"),
    error = function(e) NULL
  )

  cms <- if (!is.null(res_cms) && length(res_cms$general) > 0) {
    "Listed"
  } else {
    NA
  }

  return(tibble(
    cites_listing = cites,
    cms_presence = cms
  ))
}

