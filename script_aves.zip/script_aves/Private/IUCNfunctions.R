obtener_categoria_iucn <- function(nombre_cientifico, api) {
  partes <- strsplit(nombre_cientifico, " ")[[1]]
  if (length(partes) < 2) return(tibble(iucn_category = NA))
  
  genus <- partes[1]
  species <- partes[2]
  
  especie_df <- tryCatch(
    assessments_by_name(api, genus = genus, species = species),
    error = function(e) return(NULL)
  )
  
  if (is.null(especie_df) || nrow(especie_df) == 0) {
    return(tibble(iucn_category = NA))
  }
  
  id <- especie_df[1, "assessment_id"]
  
  detalle <- tryCatch(
    assessment_data(api, id),
    error = function(e) return(NULL)
  )
  
  if (is.null(detalle)) {
    return(tibble(iucn_category = NA))
  }
  
  categoria <- if (!is.null(detalle$red_list_category$code)) detalle$red_list_category$code else NA
  return(tibble(iucn_category = categoria))
}

