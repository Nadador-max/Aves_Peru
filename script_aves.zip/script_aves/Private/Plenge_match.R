procesar_todo <- function(df, api) {
  data("aves_peru_2025_v1", package = "avesperu")
  
  df <- df %>%
    left_join(
      aves_peru_2025_v1 %>%
        select(scientific_name, order_name, family_name, english_name, spanish_name, status),
      by = "scientific_name"
    )
  
  pre_cols <- colnames(df)[1:which(colnames(df) == "scientific_name") - 1]
  ind_col <- if ("ind" %in% colnames(df)) "ind" else NULL
  
  orden_final <- c(
    pre_cols,
    "order_name", "family_name", "scientific_name",
    "english_name", "spanish_name",
    ind_col,
    "status"
  )
  
  orden_final <- orden_final[orden_final %in% colnames(df)]
  df <- df %>% select(all_of(orden_final), everything())
  
  # Obtener IUCN
  iucn_info <- purrr::map_dfr(df$scientific_name, ~obtener_categoria_iucn(.x, api))
  df <- bind_cols(df, iucn_info)
  
  # Obtener CITES y CMS
  cites_cms_info <- purrr::map_dfr(df$scientific_name, obtener_cites_cms_rcites)
  df <- bind_cols(df, cites_cms_info)
  
  return(df)
}
